import LessonSpringBoot.ComponentLogWriter.LogFile;
import LessonSpringBoot.ComponentDataProcessing.CheckApplication;
import LessonSpringBoot.ComponentDataProcessing.CheckDate;
import LessonSpringBoot.ComponentDataProcessing.CheckFio;
import LessonSpringBoot.Model.ApplicationType;
import LessonSpringBoot.Model.FileData;
import LessonSpringBoot.Model.Logins;
import LessonSpringBoot.Model.Users;
import LessonSpringBoot.Interfaces.Repository.LoginRepoJPA;
import LessonSpringBoot.Interfaces.Repository.UserRepoJPA;
import LessonSpringBoot.Starter;
import org.junit.Assert;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.PostgreSQLContainer;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;


@SpringBootTest(classes = {Starter.class})
public class StraterTest {
    @Autowired
    CheckFio checkFio;
    @Autowired
    CheckApplication checkApplication;
    @Autowired
    CheckDate checkDate;
    @Autowired
    LogFile logFile;

    public static PostgreSQLContainer postgreSQLContainer = new PostgreSQLContainer("postgres");

    @BeforeAll
    static void beforeAll() {
        postgreSQLContainer.start();
    }

    @AfterAll
    static void afterAll() {
        postgreSQLContainer.stop();
    }

    @DynamicPropertySource
    static void confugureProperties(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", postgreSQLContainer::getJdbcUrl);
        registry.add("spring.datasource.username", postgreSQLContainer::getUsername);
        registry.add("spring.datasource.password", postgreSQLContainer::getPassword);
    }

    @Test
    void testDB() {

        Users u1 = new Users("TestDB", "Фамилия Имя Отчество");

        ApplicationContext ctx = SpringApplication.run(Starter.class);
        UserRepoJPA uRepo = ctx.getBean(UserRepoJPA.class);
        if (uRepo.findByUsername("TestDB").isEmpty()) {
            uRepo.save(u1);
        }

        Users ufind = new Users();
        ufind = uRepo.findByUsername("TestDB").get(0);
        Assert.assertNotNull(ufind);
        Assert.assertEquals(ufind.getFio(), "Фамилия Имя Отчество");

        Logins l1 = new Logins(Timestamp.valueOf(String.format("%04d-%02d-%02d 00:00:00", 2024, 12, 5)), "web", ufind.getId());
        LoginRepoJPA lRepo = ctx.getBean(LoginRepoJPA.class);
        if(lRepo.findByUserIdAndAccessDate(ufind.getId(), Timestamp.valueOf(String.format("%04d-%02d-%02d 00:00:00", 2024, 12, 5))).isEmpty()){
            lRepo.save(l1);
        }
       Logins lFind  = lRepo.findByUserIdAndAccessDate(ufind.getId(), Timestamp.valueOf(String.format("%04d-%02d-%02d 00:00:00", 2024, 12, 5))).get(0);
        Assert.assertNotNull(lFind);
        Assert.assertEquals(lFind.getUserId(), ufind.getId());
    }

    @Test
    void moduleTests() throws IOException, ParseException {
        String[] testData="TestDB; Фамилия имя Отчество; web; 01/05/2024 19:17:21".split(";");
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        FileData fd=new FileData(testData[0],testData[1],testData[2],testData[3], dateFormat.parse(testData[3]),"test");
        checkFio.process(fd);
        checkApplication.process((fd));

        Assertions.assertEquals("Фамилия Имя Отчество",fd.getFio());
        Assertions.assertEquals(ApplicationType.web.getTitle(),fd.getApplication());

         //проверили, что в лоф файле ничего нет
        logFile.InitLogFile();
        testData="TestDB; Фамилия имя Отчество; web; 01/05/2024 19:17:21".split(";");
        fd=new FileData(testData[0],testData[1],testData[2],testData[3].trim(), null,"test");
        checkDate.process(fd);
        Assert.assertNotNull(logFile.ReadLogFirstRec());

        //проверим, что лог файл содержит запись об ошибке с данными
        logFile.InitLogFile();
        testData="TestDB; Фамилия имя Отчество; web; ".split(";");
        fd=new FileData(testData[0],testData[1],testData[2],testData[3].trim(), null,"test");
        checkDate.process(fd);
        Assertions.assertEquals("-->test<--TestDB;Фамилия имя Отчество;web;",logFile.ReadLogFirstRec().trim());

    }
}
