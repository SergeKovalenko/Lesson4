package LessonSpringBoot.ComponentDataProcessing;

import LessonSpringBoot.Model.FileData;
import LessonSpringBoot.Interfaces.Processor.DataProcessor;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import static java.nio.file.StandardOpenOption.APPEND;
import static java.nio.file.StandardOpenOption.CREATE;

@Component
@Order(1)
public class CheckDate implements DataProcessor {
    private String path = new File("src/main/resources/").getAbsolutePath();

    //запись строки в файл
    void writeToLogFile(String val) throws IOException {
        try {
            Files.writeString(Path.of(path, "errors.log"), val + System.lineSeparator(), StandardCharsets.UTF_8, CREATE, APPEND);
        } catch (IOException e) {
            System.out.println(e);
        }
    }

    @Override
    //если дата не указана, записать эту строку в лог файл
    public void process(FileData val) throws IOException {
        if (val.getSAccessDate().isEmpty())
            writeToLogFile("-->" + val.getFilename() + "<--" + val.toValue());
    }

}
