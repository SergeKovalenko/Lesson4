package LessonSpringBoot.ComponentDataProcessing;


import LessonSpringBoot.Interfaces.Processor.DataProcessor;
import LessonSpringBoot.Interfaces.Processor.DataReader;
import LessonSpringBoot.Interfaces.Repository.LoginRepoJPA;
import LessonSpringBoot.Interfaces.Repository.UserRepoJPA;
import LessonSpringBoot.ComponentLogWriter.LogFile;
import LessonSpringBoot.Service.LoginService;
import LessonSpringBoot.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.text.ParseException;

import java.util.List;



@Component
public class ExecReader {
    @Autowired
    public List<DataProcessor> dataProcessors;

   public void runApp(ApplicationContext ctx) throws IOException {
       UserRepoJPA uRepo= ctx.getBean(UserRepoJPA.class);
       UserService uServ=ctx.getBean(UserService.class);
       LoginRepoJPA lRepo= ctx.getBean(LoginRepoJPA.class);
       LoginService lServ=ctx.getBean(LoginService.class);

       LogFile lf = ctx.getBean(LogFile.class);
       lf.InitLogFile();

       DataReader rf = ctx.getBean(DataReader.class);

       rf.getData().forEach(sValue -> {
           for (DataProcessor pr : dataProcessors) {
               try {
                   pr.process(sValue);
               } catch (ParseException e) {
                   e.printStackTrace();
               } catch (IOException e) {
                   e.printStackTrace();
               }
           }
           uServ.saveDate(sValue,uRepo);

           lServ.saveDate(sValue,lRepo,uRepo);
       });


    }
}
