package LessonSpringBoot.ComponentDataProcessing;

import LessonSpringBoot.Model.FileData;
import LessonSpringBoot.Model.ApplicationType;
import LessonSpringBoot.Interfaces.Processor.DataProcessor;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Order(3)
public class CheckApplication implements DataProcessor {

    @Override
    public void process(FileData val) {
        for (ApplicationType app : ApplicationType.values()) {
            if (val.getApplication().trim().equals(app.getTitle())) {
                val.setApplication(val.getApplication().trim());
                return;
            }
        }
        val.setApplication(ApplicationType.others.getTitle() + ":" + val.getApplication().trim());
    }
}
