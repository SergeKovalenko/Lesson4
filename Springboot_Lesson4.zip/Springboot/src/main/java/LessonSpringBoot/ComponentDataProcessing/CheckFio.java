package LessonSpringBoot.ComponentDataProcessing;

import LessonSpringBoot.Model.FileData;
import LessonSpringBoot.Interfaces.Processor.DataProcessor;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
@Order(2)
public class CheckFio implements DataProcessor {
    @Override
    //Корректировка фио
    public void process(FileData val) throws IOException {
        String str[] = val.getFio().trim().split(" ");
        int i = 0;
        for (String s : val.getFio().trim().split(" ")) {
            str[i] = ("" + s.charAt(0)).toUpperCase() + s.substring(1);
            i++;
        }
        val.setFio(String.join(" ", str));

    }
}

