package LessonSpringBoot.ComponentReader;

import LessonSpringBoot.Model.FileData;
import LessonSpringBoot.Interfaces.Processor.DataReader;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

@Component
public class ReadFromFiles implements DataReader {
    private List<FileData> fileData = new ArrayList<FileData>();
    private String path=new File("src/main/resources/").getAbsolutePath();

    private List<File> getFileList() {
        FileFilter fltr = new FileFilter() {
            @Override
            public boolean accept(File pathname) {
                return pathname.getName().endsWith(".txt");
            }
        };
        File[] arrFiles = new File(path).listFiles(fltr);
        return Arrays.asList(arrFiles);
    }

    @Override
    public List<FileData> getData() {
        List<FileData> fileData= new ArrayList<FileData>();
        List<File> lst = getFileList();
        for (File file : lst) {
            try {
                Scanner scanner = new Scanner(file);
                while (scanner.hasNextLine()) {
                    String[] str = scanner.nextLine().split(";");
                    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                    try {
                        fileData.add(new FileData(str[0], str[1], str[2], str[3], dateFormat.parse(str[3]),file.getName()));
                    } catch (Exception e) {
                        fileData.add(new FileData(str[0], str[1], str[2],"",null,file.getName()));
                    }
                }
                scanner.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return fileData;
    }

}
