package LessonSpringBoot.Model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

@Entity
@Table(name = "Logins")
@Getter @Setter @ToString
public class Logins {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id")
    private Long id;

    @Column(name = "access_date")
    private Date accessDate;

    @Column(name = "application")
    private String application;

    @Column(name = "user_id")
    private Long userId;

    public Logins() {
    }
    public Logins(Date accessDate, String application, Long userId) {
        this.accessDate = accessDate;
        this.application = application;
        this.userId = userId;
    }
}
