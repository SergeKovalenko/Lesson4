package LessonSpringBoot.Model;

import lombok.*;
import java.util.Date;

@ToString
@Getter
@Setter
public class FileData {
    private String username;
    private String fio;
    private String application;
    private String sAccessDate;
    private Date accessDate;
    private String filename;


    public FileData(String username, String fio, String application, String sAccessDate, Date accessDate, String filename) {
        this.username = username;
        this.fio = fio;
        this.application = application;
        this.sAccessDate = sAccessDate;
        this.accessDate = accessDate;
        this.filename = filename;
    }
    public String toValue(){
        return username.trim()+";"+fio.trim()+";"+application.trim()+";"+sAccessDate.trim();
    }

}
