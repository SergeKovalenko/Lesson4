package LessonSpringBoot.Model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "Users")
@Getter @Setter @ToString
public class Users {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id")
    private Long id;

    @Column(name = "username")
    private String username;

    @Column(name = "fio")
    private String fio;
    public Users() {
    }
     public Users(String username, String fio) {
        this.username = username;
        this.fio = fio;
    }
}
