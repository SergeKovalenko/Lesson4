package LessonSpringBoot.Model;

import lombok.Getter;
import lombok.ToString;

@ToString
@Getter
public enum ApplicationType {
    web("web"), mobile("mobile"),others("others");
    private String title;

    ApplicationType(String title) {
        this.title = title;
    }
}

