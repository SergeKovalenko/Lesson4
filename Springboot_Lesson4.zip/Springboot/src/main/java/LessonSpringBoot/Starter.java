package LessonSpringBoot;

import LessonSpringBoot.ComponentDataProcessing.ExecReader;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import java.io.IOException;


@SpringBootApplication(scanBasePackages = "LessonSpringBoot")
public class Starter {
    public static void main(String[] args) throws IOException {

        ApplicationContext ctx= SpringApplication.run(Starter.class,args);
        ExecReader exc = ctx.getBean(ExecReader.class);
        exc.runApp(ctx);

     }
}

