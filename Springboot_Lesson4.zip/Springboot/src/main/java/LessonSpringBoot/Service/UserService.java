package LessonSpringBoot.Service;

import LessonSpringBoot.Model.FileData;
import LessonSpringBoot.Model.Users;
import LessonSpringBoot.Interfaces.Repository.UserRepoJPA;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    @Autowired
    UserRepoJPA repo;

    public void updateUsersFio(long id, String fio) {
        Users myUsers = repo.findById(id);
        myUsers.setFio(fio);
        repo.save(myUsers);
    }

    public void saveDate(FileData val, UserRepoJPA repo) {
            if (repo.findByUsername(val.getUsername()).isEmpty()) {
                Users us = new Users();
                us.setUsername(val.getUsername());
                us.setFio(val.getFio());
                repo.save(us);
            } else {
                Users us = repo.findByUsername(val.getUsername()).get(0);
                updateUsersFio(us.getId(), val.getFio());
            }
    }

    public void save(Users val) {
        val.setUsername(val.getUsername());
        val.setFio(val.getFio());
        repo.save(val);
    }
}
