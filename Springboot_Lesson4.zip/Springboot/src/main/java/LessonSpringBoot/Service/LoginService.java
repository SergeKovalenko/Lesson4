package LessonSpringBoot.Service;

import LessonSpringBoot.Model.FileData;
import LessonSpringBoot.Model.Logins;
import LessonSpringBoot.Interfaces.Repository.LoginRepoJPA;
import LessonSpringBoot.Interfaces.Repository.UserRepoJPA;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LoginService {
    @Autowired
    LoginRepoJPA repo;

    public void saveDate(FileData val, LoginRepoJPA lRepo, UserRepoJPA uRepo) {
        if (!val.getSAccessDate().isEmpty()) {
            if (!uRepo.findByUsername(val.getUsername()).isEmpty()) {
                Logins lgn = new Logins();
                lgn.setUserId(uRepo.findByUsername(val.getUsername()).get(0).getId());

                if (lRepo.findByUserIdAndAccessDate(lgn.getUserId(), val.getAccessDate()).isEmpty()) {
                    lgn.setAccessDate(val.getAccessDate());
                    lgn.setApplication(val.getApplication());
                    lRepo.save(lgn);
                }
            }
        }
    }
}
