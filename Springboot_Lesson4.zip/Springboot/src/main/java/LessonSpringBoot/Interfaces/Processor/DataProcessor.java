package LessonSpringBoot.Interfaces.Processor;

import LessonSpringBoot.Model.FileData;

import java.io.IOException;
import java.text.ParseException;

public interface DataProcessor {
    void process (FileData str) throws ParseException, IOException;
}
