package LessonSpringBoot.Interfaces.Processor;


import LessonSpringBoot.Model.FileData;

import java.util.List;

public interface DataReader {
    List<FileData> getData();
}
