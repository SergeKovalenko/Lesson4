package LessonSpringBoot.Interfaces.Repository;

import LessonSpringBoot.Model.Logins;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Date;
import java.util.List;

public interface LoginRepoJPA extends JpaRepository<Logins, Long> {
   List<Logins>findByUserIdAndAccessDate(Long userId, Date accessDate);
}
