package LessonSpringBoot.Interfaces.Repository;

import LessonSpringBoot.Model.Users;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UserRepoJPA extends JpaRepository<Users, Long> {
    List<Users> findByUsername(String username);
    Users findById(long id);
}

