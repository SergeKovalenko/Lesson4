package LessonSpringBoot.Interfaces.LogWriter;

public interface DataLogWriter {
    void InitLogFile();
    String ReadLogFirstRec();
}
