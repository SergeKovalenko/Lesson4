package LessonSpringBoot.ComponentLogWriter;

import LessonSpringBoot.Interfaces.LogWriter.DataLogWriter;
import org.springframework.stereotype.Component;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

@Component
//для записи логов ошибочных записей(там где нет даты)
public class LogFile implements DataLogWriter {
    private String path = new File("src/main/resources/").getAbsolutePath();

    @Override
    public void InitLogFile(){
        try {
            Files.writeString(Path.of(path, "errors.log"), "");
        } catch (IOException e) {
            System.out.println(e);
        }
    }
    @Override
    public String ReadLogFirstRec(){
        try {
            return Files.readString(Path.of(path, "errors.log"));
        } catch (IOException e) {
            System.out.println(e);
        }
        return null;
    }

}
